```chart
type: line
id: board
file: Training
```
