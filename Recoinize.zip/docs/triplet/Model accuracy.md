```chart
	type: radar
    labels: [Train set, Test set, Validation set]
    series:
        - title: Triplet network
          data: [0.96,0.90,0.91]
        - title: Siamese network
          data: [0.92,0.87,0.85]
    width: 50%
```

