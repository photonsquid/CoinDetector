| Train | Test | Validation |
| ----- | ---- | ---------- |
| 1932  | 414  | 414        |
^distribution
```chart
	type: pie
	labels: [Train, Test, Validation]
	series:
		- data: [1932, 414, 414]
	labelColors: true
	width: 50%
```

